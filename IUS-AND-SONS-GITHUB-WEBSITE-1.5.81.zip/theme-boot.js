/* IUS AND SONS 1.5.30 (1.5.35: design themes) — makes every page follow the system colour and mode.
   Reads the Appearance setting, sets --logo-rot (turns the logo to the system colour) and --sys (glow colour),
   keeps them in step when colours are changed in Settings, and applies Dark/Light mode on pages without the dashboard script. */
(function(){
  var K='ius_sons_appearance_v2',root=document.documentElement,BASE=265;   /* the logo is drawn in purple (hue ≈ 265°) */
  /* 1.5.35: pages after sign-in (<html data-area="app">) use the Classic design (version 1.5.26 look, Light Mode) by default;
     the Liquid Glass and Vivid designs can be chosen as themes in the top bar. Home / sign-in / admin pages always stay Liquid Glass. */
  /* 1.5.37: start-up splash decided here (in <head>) so it shows from the very first frame, or never flashes on later pages. */
  (function(){
    var play=true;
    try{
      var lid=window.iusWindow&&window.iusWindow.launchId;
      if(lid){play=localStorage.getItem('ius_launch_seen')!==lid;if(play)localStorage.setItem('ius_launch_seen',lid)}   /* Windows app: every new launch starts with the splash */
      else play=!(sessionStorage.getItem('ius_intro_played_v2')==='1'||(Date.now()-(+localStorage.getItem('ius_alive_v2')||0))<4500)
    }catch(e){}
    window.IUS_SPLASH_PLAY=play;
    root.classList.add(play?'ius-splashing':'ius-skip-splash');
  })();
  var APP=root.getAttribute('data-area')==='app'&&(function(){try{return !!localStorage.getItem('ius_sons_local_session_v1')}catch(e){return false}})();
  function read(){try{return JSON.parse(localStorage.getItem(K)||'{}')||{}}catch(e){return {}}}
  function hue(hex){
    var m=/^#?([0-9a-f]{6})$/i.exec(String(hex||'').trim());if(!m)return null;
    var n=parseInt(m[1],16),r=(n>>16&255)/255,g=(n>>8&255)/255,b=(n&255)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;
    if(d<0.04)return null;
    var h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h=Math.round(h*60);return h<0?h+360:h;
  }
  function setv(k,v){if(root.style.getPropertyValue(k)!==v)root.style.setProperty(k,v)}
  function sync(){
    var a=read(),c=(root.style.getPropertyValue('--ius-topbar')||'').trim()||a.topbar||'#123F70',h=hue(c);
    setv('--logo-rot',(h===null?211-BASE:h-BASE)+'deg');
    setv('--logo-sat',h===null?'0.15':'1');
    setv('--sys',/^#[0-9a-f]{6}$/i.test(c)?c:'#123F70');
  }
  sync();
  try{new MutationObserver(sync).observe(root,{attributes:true,attributeFilter:['style']})}catch(e){}
  addEventListener('storage',function(e){if(e.key===K){sync();mode();applyDesign()}});
  function design(){if(!APP)return 'glass';var d=read().design;return d==='glass'||d==='vivid'?d:'classic'}
  function applyDesign(){
    var d=design();if(root.getAttribute('data-design')!==d)root.setAttribute('data-design',d);
    var l=document.getElementById('iusGlassCss'),m=d==='glass'?'all':'not all';if(l&&l.media!==m)l.media=m;
  }
  function mode(){var a=read();if(document.body)document.body.classList.toggle('dark-mode',(a.mode||(APP?'light':'dark'))!=='light')}
  window.IUS_THEME={design:design,applyDesign:applyDesign,isApp:APP};
  applyDesign();
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){mode();applyDesign()});else mode();
})();
